class ColorsApp {
  final bgColor = 0xffF1F6F9;
}
